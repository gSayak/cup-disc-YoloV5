# cupAndDiscSegmentation > 2023-04-24 11:04pm
https://universe.roboflow.com/techno-international-new-town-mcxop/cupanddiscsegmentation

Provided by a Roboflow user
License: CC BY 4.0

